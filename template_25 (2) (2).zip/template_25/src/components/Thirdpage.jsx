import React from "react";

const Third =()=>{
    return(
        <>
         <div className="twitter group">
      <div className="row-2 group">
        <div className="title-4">
          <p className="twitter-2">twitter</p>
          <div className="title-deco-line-4" />
        </div>
        <img
          className="icon-twitter-xf099-copy"
          src="images/icon-twitter_xf099.png"
          alt=""
          width={28}
          height={22}
          title=""
        />
      </div>
      <p className="text-11">
        Unerdwear cookie liquorice. Cake donut cupcake lollipop soufflé candy.
        Chocolate oat cake <span className="fw600">@cheesecake</span> tootsie
        roll.
      </p>
    </div>
    <div className="section group">
      <div className="col-2">
        <div className="title-5">
          <p className="text-12">Just default Section</p>
          <div className="title-deco-line-5" />
        </div>
        <p className="text-13">
          Bear claw marzipan bear claw applicake I love muffin. Lemon drops gummi
          bears pastry gummi bears sesame snaps I love unerdwear.com. Soufflé
          cotton candy dessert candy ice cream wafer gummies cheesecake brownie.
          <br />
          <span className="text-style">&nbsp;</span>
          <br />
          Muffin chupa chups jelly beans sweet pie applicake. Croissant chocolate
          cake I love pudding. Ice cream I love powder pudding apple pie
          marshmallow. Cupcake marzipan oat cake bonbon I love candy canes toffee.
        </p>
        <div className="button-2"><a href="">visit me</a></div>
      </div>
      <img
        className="vimeo"
        src="images/vimeo.jpg"
        alt=""
        width={560}
        height={313}
      />
    </div>
        </>
    )
}
export default Third