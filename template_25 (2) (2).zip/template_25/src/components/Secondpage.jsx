import React from "react";

const Second =()=>{
    return(
        <>
        <div className="testiomonials">
      <div className="row group">
        <div className="title-2">
          <p className="testimonials">Testimonials</p>
          <div className="title-deco-line-2" />
        </div>
        <p className="text-5">”</p>
      </div>
      <p className="text-6">
        Applicake chocolate cake wafer toffee pie soufflé wafer. Tart marshmallow
        wafer macaroon cheesecake jelly. Gingerbread cookie soufflé sweet roll
        sweet roll jelly-o.
      </p>
      <p className="text-7">-Walter White</p>
    </div>
    <div className="who-is" id="features">
      <div className="title-3">
        <p className="text-8">Who is john doe?</p>
        <div className="title-deco-line-3" />
      </div>
      <div className="row-6 group">
        <p className="text-9">
          Bear claw marzipan bear claw applicake I love muffin. Lemon drops gummi
          bears pastry gummi bears sesame snaps I love unerdwear.com. Soufflé
          cotton candy dessert candy ice cream wafer gummies cheesecake brownie.
          <br />
          <span className="text-style">&nbsp;</span>
          <br />
          Muffin chupa chups jelly beans sweet pie applicake. Croissant chocolate
          cake I love pudding. Ice cream I love powder pudding apple pie
          marshmallow. Cupcake marzipan oat cake bonbon I love candy canes toffee.
        </p>
        <div className="col-6">
          <p className="text-10">
            Pudding dessert jujubes tiramisu gingerbread croissant tiramisu
            applicake. Sesame snaps sugar plum cotton candy chocolate bonbon lemon
            drops candy canes cotton candy. Cake toffee pie bear claw pastry.
          </p>
          <div className="social-icons match-height group">
            <div className="rectangle-4-holder">
              <img
                className="icon-twitter-xf099"
                src="images/icon-twitter_xf099.png"
                alt=""
                width={28}
                height={22}
                title=""
              />
            </div>
            <div className="rectangle-4-copy-holder">
              <img
                className="icon-google-plus-xf0d5"
                src="images/icon-google-plus_xf0d5.png"
                alt=""
                width={28}
                height={29}
                title=""
              />
            </div>
            <div className="rectangle-4-copy-2-holder">
              <img
                className="icon-dribbble-xf17d"
                src="images/icon-dribbble_xf17d.png"
                alt=""
                width={26}
                height={27}
                title=""
              />
            </div>
            <div className="rectangle-4-copy-3-holder">
              <img
                className="icon-coffee-xf0f4"
                src="images/icon-coffee_xf0f4.png"
                alt=""
                width={31}
                height={24}
                title=""
              />
            </div>
          </div>
        </div>
      </div>
    </div>
        </>
    )
}
export default Second